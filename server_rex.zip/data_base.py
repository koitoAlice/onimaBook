import sqlite3
f = open("recipe.sql", "r")
conn = sqlite3.connect('recipe.db')

adddddd = f.read().split('\n')
for item in adddddd:
	conn.execute(item);

'''
CREATE TABLE recipe(
   ...> id INT,
   ...> idAutors INT,
   ...> idThemeOnForum INT,
   ...> textRecipe TEXT,
   ...> ingredients TEXT,
   ...> title TEXT,
   ...> photo_url TEXT,
   ...> time INT,
   ...> categoryId INT
   ...> );
CREATE TABLE themeOnForum(
   ...> id INT,
   ...> textTheme TEXT,
   ...> idComment TEXT
   ...> );

def print_db(row):
	for row in cursor:
		for i in range(9):
			print(row[i])
		print('--------------------------------------')

def base_return(row):
	return row
base_return(row)

print ("ID = ", row[0])
print ("idAutors = ", row[1])
print ("idThemeOnAuthors = ", row[2])
print ("textRecipe = ", row[3], "\n")
'''
conn.commit()
#conn.close()
