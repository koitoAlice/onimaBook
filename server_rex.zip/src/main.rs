use server_rex::ThreadPool;
use std::fs;
use std::io::prelude::*;
use std::net::TcpListener;
use std::net::TcpStream;
use std::thread;
use std::time::Duration;
use std::str;
use pyo3::{prelude::*, types::{IntoPyDict, PyModule}};

fn main() {
    let listener = TcpListener::bind("192.168.0.104:7878").unwrap();
    println!("[INFO] BIND :7878");
    println!("load_comment: {:?}", load_comment("0,1,2,3,4".to_string()));
    let pool = ThreadPool::new(4);
    for stream in listener.incoming() {
        let stream = stream.unwrap();
        pool.execute(|| {
			println!("[INFO] client connection");
            handle_connection(stream);
			println!("[INFO] client disconnect");
        });
    }

    println!("Shutting down.");
}

fn handle_connection(mut stream: TcpStream) {
    let mut buffer = [0; 1024];
    stream.read(&mut buffer).unwrap();

    let get = b"GET / HTTP/1.1\r\n";
    let sleep = b"GET /sleep HTTP/1.1\r\n";
    let theme = b"GET /forumTheme:";
    let commentCount = b"GET /forumThemeLenght:";
	let mut temp1 = String::new();
    let (status_line, filename) = if buffer.starts_with(get) {
		let db = load_recipe();
		let mut res_val: String = String::new();
		for val11 in db {
			res_val += val11.as_str();
			res_val.push('\n');
		}
		println!("[INFO] get db");
		let response = format!(
			"HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n{}",
			res_val.len(),
			res_val
		);
		stream.write(response.as_bytes()).unwrap();
		stream.flush().unwrap();
        return;
    } else if buffer.starts_with(theme) {
        //thread::sleep(Duration::from_secs(5));
        //let db = load_database();
        let string_from_buffer = String::from_utf8(buffer.to_vec()).unwrap();
        let theme_id = string_from_buffer.split('?').collect::<Vec<&str>>()[0].split(':').collect::<Vec<&str>>()[1].to_string();
        println!("theme_id: {}", theme_id);
        let ktemp = theme_id.clone();
        let loadtheme = load_theme(ktemp);
        let mut res_val: String = String::new();
        let mut db: Vec<String> = Vec::new();
        if loadtheme.len() > 1 {
			 db = load_comment(loadtheme[1].clone());		
		} else {
			db = load_comment("0".to_string());
		}
		for val11 in db {
			res_val += val11.as_str();
			res_val.push('\n');
		}
		for i in 0..1024 {
			res_val += " ";
		}
		println!("[INFO] get comments");
		let response = format!(
			"HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n{}",
			res_val.chars().count(),
			res_val
		);
		println!("{}", response.clone());
		stream.write(response.as_bytes()).unwrap();
		stream.flush().unwrap();
		return;
    } else if buffer.starts_with(commentCount) {
		//thread::sleep(Duration::from_secs(5));
        //let db = load_database();
		let mut res_val: String = "1".to_string();
		/*for val11 in db {
			res_val += val11.as_str();
			res_val.push('\n');
		}*/
		println!("[INFO] get comments lenght");
		let response = format!(
			"HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n{}",
			res_val.chars().count(),
			res_val
		);
		stream.write(response.as_bytes()).unwrap();
		stream.flush().unwrap();
		return;
    } else {
        //("HTTP/1.1 404 NOT FOUND", "/home/hatsune/server_rex/src/404.html")
        println!("[WARN] 404 error");
        println!("{}", str::from_utf8(&buffer).unwrap());
        let mut temp: String = str::from_utf8(&buffer).unwrap().to_string();
        let resurse: &str = temp.split(' ').collect::<Vec<&str>>()[1].split('/').collect::<Vec<&str>>()[1];
        temp1 = String::new(); //format!("/home/hatsune/server_rex/jquery_responce/theme{}.json", resurse);
        let mut temp2 = load_theme(resurse.to_string()).clone();
        if temp2.len() > 0 {
			let temp2 = temp2.clone(); //&temp2[0].split(' ').collect::<Vec<&str>>()[0..3];
			//println!("asdasdsadasdasd {:?}", temp2.to_vec());
			//temp1 = String::new();
			//temp1 += temp2[0]; temp1.push(' '); temp1 += temp2[1]; temp1.push(' '); temp1 += temp2[2];*/
			("HTTP/1.1 200 OK", temp2[0].clone())
			//("HTTP/1.1 200 OK", "")
		} else {
			("HTTP/1.1 200 OK", "".to_string())
		}        
    };

    let contents = filename.clone();/*= match fs::read_to_string(filename){
			Ok(A) => A,
			Err(e) => {"none".to_string()},
	};*/

    let response = format!(
        "{}\r\nContent-Length: {}\r\n\r\n{}",
        status_line,
        contents.len(),
        contents
    );

    stream.write(response.as_bytes()).unwrap();
    stream.flush().unwrap();
}

fn load_recipe() -> Vec<String>{
    let gil = Python::acquire_gil();
    let py = gil.python();
    let sys = py.import("sys").unwrap();
    let version: String = sys.get("version").unwrap().extract().unwrap();

    let locals = [("os", py.import("os").unwrap())
        /*, ("tensorflow", py.import("tensorflow")?), ("keras", py.import("keras")?)*/
    ].into_py_dict(py);
    let code = "os.getenv('USER') or os.getenv('USERNAME') or 'Unknown'";
    let user: String = py.eval(code, None, Some(&locals)).unwrap().extract().unwrap();

    println!("Hello {}, I'm Python {}", user, version);
    //Python::with_gil(|py| {
    let db = PyModule::from_code(py, r#"
import sqlite3

conn = sqlite3.connect('recipe.db')

#conn.execute("INSERT INTO recipe (ID,idAutors,idThemeOnForum,textRecipe,ingredients,title,photo_url,time,categoryId) VALUES (0, 0, 0, 'калифорния это просто (тестовый пост)', '1,2,3,4', 'Супер ракета!', 'https://sun1-23.userapi.com/s/v1/ig2/rinD2RcJhCP8QfnZz5s6l6ZyooNoDK89tCvPOJjlUugFRVDRVXwNIQ3St98JeB11y1T-u62HUgaxmpFHu15I1rTR.jpg?size=200x0&quality=96&crop=300,211,864,864&ava=1',15, 1)");
cursor = conn.execute("SELECT ID,idAutors,idThemeOnForum,textRecipe,ingredients,title,photo_url,time,categoryId from recipe")
'''
CREATE TABLE recipe(
   ...> id INT,
   ...> idAutors INT,
   ...> idThemeOnForum INT,
   ...> textRecipe TEXT,
   ...> ingredients TEXT,
   ...> title TEXT,
   ...> photo_url TEXT,
   ...> time INT,
   ...> categoryId INT
   ...> );
'''
def print_db(row):
	for row in cursor:
		for i in range(9):
			print(row[i])
		print('--------------------------------------')

result = []
row_ = []
for row in cursor:
	for i in range(9):
		#print(row[i])
		row_.append(str(row[i]).replace('\\r', '').replace('\\n', ' <br> '))
def base_return():
	return row_
'''
print ("ID = ", row[0])
print ("idAutors = ", row[1])
print ("idThemeOnAuthors = ", row[2])
print ("textRecipe = ", row[3], "\n")
'''
#conn.commit()
conn.close()

"#, "db.py", "db").unwrap();

    let result: Vec<String> = db.call0("base_return").unwrap().extract().unwrap();    
    result
}

fn load_theme(theme_id: String) -> Vec<String>{
	let gil = Python::acquire_gil();
    let py = gil.python();
    /*let sys = py.import("sys").unwrap();
    let version: String = sys.get("version").unwrap().extract().unwrap();

    let locals = [("os", py.import("os").unwrap())
        /*, ("tensorflow", py.import("tensorflow")?), ("keras", py.import("keras")?)*/
    ].into_py_dict(py);
    let code = "os.getenv('USER') or os.getenv('USERNAME') or 'Unknown'";
    let user: String = py.eval(code, None, Some(&locals)).unwrap().extract().unwrap();

    println!("Hello {}, I'm Python {}", user, version);*/
    //Python::with_gil(|py| {
    let db = PyModule::from_code(py, r#"
#conn.execute("INSERT INTO recipe (ID,idAutors,idThemeOnForum,textRecipe,ingredients,title,photo_url,time,categoryId) VALUES (0, 0, 0, 'калифорния это просто (тестовый пост)', '1,2,3,4', 'Супер ракета!', 'https://sun1-23.userapi.com/s/v1/ig2/rinD2RcJhCP8QfnZz5s6l6ZyooNoDK89tCvPOJjlUugFRVDRVXwNIQ3St98JeB11y1T-u62HUgaxmpFHu15I1rTR.jpg?size=200x0&quality=96&crop=300,211,864,864&ava=1',15, 1)");
def returnTheme(idTheme):
	import sqlite3

	conn = sqlite3.connect('recipe.db')
	cursor = conn.execute("SELECT textTheme,idComment from themeOnForum WHERE themeOnForum.id =" + idTheme)
	'''
	CREATE TABLE recipe(
	   ...> id INT,
	   ...> idAutors INT,
	   ...> idThemeOnForum INT,
	   ...> textRecipe TEXT,
	   ...> ingredients TEXT,
	   ...> title TEXT,
	   ...> photo_url TEXT,
	   ...> time INT,
	   ...> categoryId INT
	   ...> );
	'''
	row_ = []
	for row in cursor:
		if row == '':
			row_.append('none')
			row_.append('0')
			conn.close()
			return row_
		for i in range(2):
			#print(row[i])
			row_.append(str(row[i]))
	conn.close()
	return row_

"#, "db1.py", "db").unwrap();

    let result: Vec<String> = db.call1("returnTheme", (theme_id.clone(),)).unwrap().extract().unwrap();
    //println!("{:?}", result);
    result

}

fn load_comment(ids: String) -> Vec<String> {
	let id = ids.split(',').collect::<Vec<&str>>();
	println!("{:?}", id);
	let gil = Python::acquire_gil();
    let py = gil.python();
    let sys = py.import("sys").unwrap();
    let version: String = sys.get("version").unwrap().extract().unwrap();

    let locals = [("os", py.import("os").unwrap())
        /*, ("tensorflow", py.import("tensorflow")?), ("keras", py.import("keras")?)*/
    ].into_py_dict(py);
    let code = "os.getenv('USER') or os.getenv('USERNAME') or 'Unknown'";
    let user: String = py.eval(code, None, Some(&locals)).unwrap().extract().unwrap();

    //println!("Hello {}, I'm Python {}", user, version);
    //Python::with_gil(|py| {
    let db = PyModule::from_code(py, r#"
#conn.execute("INSERT INTO recipe (ID,idAutors,idThemeOnForum,textRecipe,ingredients,title,photo_url,time,categoryId) VALUES (0, 0, 0, 'калифорния это просто (тестовый пост)', '1,2,3,4', 'Супер ракета!', 'https://sun1-23.userapi.com/s/v1/ig2/rinD2RcJhCP8QfnZz5s6l6ZyooNoDK89tCvPOJjlUugFRVDRVXwNIQ3St98JeB11y1T-u62HUgaxmpFHu15I1rTR.jpg?size=200x0&quality=96&crop=300,211,864,864&ava=1',15, 1)");
def returnTheme(idTheme):
	import sqlite3

	conn = sqlite3.connect('recipe.db')
	cursor = conn.execute("SELECT text,idAuthors,description from comment WHERE comment.id =" + idTheme)
	'''
	CREATE TABLE comment(
	   ...> id INT,
	   ...> text TEXT,
	   ...> idAuthors int,
	   ...> description TEXT
	   ...> );

	'''
	row_ = []
	for row in cursor:
		for i in range(3):
			#print(row[i])
			row_.append(str(row[i]))
	conn.close()
	return row_
def returnAuthorName(idAuthor):
	import sqlite3

	conn = sqlite3.connect('recipe.db')
	cursor = conn.execute("SELECT name from authors WHERE authors.ID =" + idAuthor)
	'''
	CREATE TABLE comment(
	   ...> id INT,
	   ...> text TEXT,
	   ...> idAuthors int,
	   ...> description TEXT
	   ...> );

	'''
	row_ = ''
	for row in cursor:
		row_ = str(row[0])
	conn.close()
	return row_
"#, "db.py", "db").unwrap();
	let mut res: Vec<String> = Vec::new();
	for i in 0..id.len() {
		let result: Vec<String> = db.call1("returnTheme", (id[i].to_string().clone(),)).unwrap().extract().unwrap();
		for u in 0..3 {
			if u == 1 {
				let name: String = db.call1("returnAuthorName", (result[u].to_string().clone(),)).unwrap().extract().unwrap();
				println!("{:?}", name);
				res.push(name.clone()); continue;
			}
			res.push(result[u].clone());
		}
    }
    res
}
