INSERT INTO `authors` VALUES (0, 0, 'Админ', 'Админович', 'description');
